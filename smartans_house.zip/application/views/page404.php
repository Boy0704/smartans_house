<div class="col-md-12">
  <div class="alert alert-success">
    <h2>Halaman dalam tahap Development...</h2>
  </div>
</div>