
        <table class="table">
	    <tr><td>LOCATION ID</td><td><?php echo $LOCATION_ID; ?></td></tr>
	    <tr><td>LOCATION NAME</td><td><?php echo $LOCATION_NAME; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('smartans_location') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        