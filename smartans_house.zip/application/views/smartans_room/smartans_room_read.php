
        <table class="table">
	    <tr><td>LOCATION ID</td><td><?php echo $LOCATION_ID; ?></td></tr>
	    <tr><td>ROOM ID</td><td><?php echo $ROOM_ID; ?></td></tr>
	    <tr><td>ROOM NAME</td><td><?php echo $ROOM_NAME; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('smartans_room') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        