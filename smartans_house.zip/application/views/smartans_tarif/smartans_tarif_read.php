
        <table class="table">
	    <tr><td>LOCATION ID</td><td><?php echo $LOCATION_ID; ?></td></tr>
	    <tr><td>ROOM NO</td><td><?php echo $ROOM_NO; ?></td></tr>
	    <tr><td>TARIF ROOM</td><td><?php echo $TARIF_ROOM; ?></td></tr>
	    <tr><td>TARIF LISTRIK</td><td><?php echo $TARIF_LISTRIK; ?></td></tr>
	    <tr><td>TARIF AIR</td><td><?php echo $TARIF_AIR; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('smartans_tarif') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        