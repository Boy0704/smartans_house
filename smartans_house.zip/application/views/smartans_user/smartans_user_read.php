
        <table class="table">
	    <tr><td>EMAIL</td><td><?php echo $EMAIL; ?></td></tr>
	    <tr><td>PASSWORD</td><td><?php echo $PASSWORD; ?></td></tr>
	    <tr><td>FIRST NAME</td><td><?php echo $FIRST_NAME; ?></td></tr>
	    <tr><td>LAST NAME</td><td><?php echo $LAST_NAME; ?></td></tr>
	    <tr><td>MOBILE NO</td><td><?php echo $MOBILE_NO; ?></td></tr>
	    <tr><td>LOCATION ID</td><td><?php echo $LOCATION_ID; ?></td></tr>
	    <tr><td>ROOM ID</td><td><?php echo $ROOM_ID; ?></td></tr>
	    <tr><td>ACTIVE FLAG</td><td><?php echo $ACTIVE_FLAG; ?></td></tr>
	    <tr><td>LEVEL</td><td><?php echo $LEVEL; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('smartans_user') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        