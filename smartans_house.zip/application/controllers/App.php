<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends CI_Controller {

	public $image = '';
	
	public function index()
	{
        if ($this->session->userdata('level') == '') {
            redirect('login');
        }
		$data = array(
			'konten' => 'home_admin',
            'judul_page' => 'Dashboard',
		);
		$this->load->view('v_index', $data);
    }

    public function admin()
	{
        // if ($this->session->userdata('username') == '') {
        //     redirect('app/login');
        // }
		$data = array(
			'konten' => 'home_admin',
            'judul_page' => 'Dashboard',
		);
		$this->load->view('v_index', $data);
    }

    public function power_usage()
    {
    	if ($_GET) {
    		$data = array(
				'konten' => 'detail_power_usage',
	            'judul_page' => 'Power Usage',
			);
			$this->load->view('v_index', $data);
    	}else{
    		$data = array(
				'konten' => 'power_usage',
	            'judul_page' => 'Power Usage',
			);
			$this->load->view('v_index', $data);
    	}
    }

    public function aktifkan_akun($id_user)
    {
    	$this->db->where('ID_USER', $id_user);
    	$this->db->update('smartans_user', array('ACTIVE_FLAG'=>'y'));
    	redirect('smartans_user','refresh');
    }

    public function add_pembayaran($no_invoice,$total_tagihan)
    {
    	$data = array(
			'konten' => 'pembayaran/add',
            'judul_page' => 'Tambah Pembayaran',
            'no_invoice'=>$no_invoice,
            'total_tagihan'=>$total_tagihan,
		);
		$this->load->view('v_index', $data);
    }

    public function simpan_pembayaran()
    {
    	$_POST['date_create']=get_waktu();
    	$this->db->insert('smartans_pembayaran', $_POST);
    	$this->db->where('no_invoice', $_POST['no_invoice']);
    	$this->db->update('smartans_tagihan_header', array('status'=>'PAID'));
    	$this->session->set_flashdata('message', alert_biasa('Pembayaran berhasil disimpan !','success'));
		redirect('app/billing_list','refresh');
    }

    public function send_inv()
    {
    	$data = array(
			'konten' => 'kirim_invoice',
            'judul_page' => 'Kirim Invoice',
		);
		$this->load->view('v_index', $data);
    }

    public function water_usage()
    {
    	if ($_GET) {
    		$data = array(
				'konten' => 'detail_water_usage',
	            'judul_page' => 'Water Usage',
			);
			$this->load->view('v_index', $data);
    	}else{
    		$data = array(
				'konten' => 'water_usage',
	            'judul_page' => 'Water Usage',
			);
			$this->load->view('v_index', $data);
    	}
    }

    public function billing_list()
    {
    	$data = array(
			'konten' => 'billing_list',
            'judul_page' => 'Billing List',
		);
		$this->load->view('v_index', $data);
    }

    

   
	

	

	
}
